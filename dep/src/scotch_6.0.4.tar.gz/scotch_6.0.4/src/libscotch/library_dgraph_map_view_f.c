/* Copyright 2008,2010,2012 IPB, Universite de Bordeaux, INRIA & CNRS
**
** This file is part of the Scotch software package for static mapping,
** graph partitioning and sparse matrix ordering.
**
** This software is governed by the CeCILL-C license under French law
** and abiding by the rules of distribution of free software. You can
** use, modify and/or redistribute the software under the terms of the
** CeCILL-C license as circulated by CEA, CNRS and INRIA at the following
** URL: "http://www.cecill.info".
** 
** As a counterpart to the access to the source code and rights to copy,
** modify and redistribute granted by the license, users are provided
** only with a limited warranty and the software's author, the holder of
** the economic rights, and the successive licensors have only limited
** liability.
** 
** In this respect, the user's attention is drawn to the risks associated
** with loading, using, modifying and/or developing or reproducing the
** software by the user in light of its specific status of free software,
** that may mean that it is complicated to manipulate, and that also
** therefore means that it is reserved for developers and experienced
** professionals having in-depth computer knowledge. Users are therefore
** encouraged to load and test the software's suitability as regards
** their requirements in conditions enabling the security of their
** systems and/or data to be ensured and, more generally, to use and
** operate it in the same conditions as regards security.
** 
** The fact that you are presently reading this means that you have had
** knowledge of the CeCILL-C license and that you accept its terms.
*/
/************************************************************/
/**                                                        **/
/**   NAME       : library_dgraph_map_view_f.c             **/
/**                                                        **/
/**   AUTHOR     : Francois PELLEGRINI                     **/
/**                                                        **/
/**   FUNCTION   : This module is the Fortran API for the  **/
/**                distributed mapping handling routines   **/
/**                of the libSCOTCH library.               **/
/**                                                        **/
/**   DATES      : # Version 5.1  : from : 27 jul 2008     **/
/**                                 to     27 mar 2010     **/
/**                # Version 6.0  : from : 29 nov 2012     **/
/**                                 to     29 nov 2012     **/
/**                                                        **/
/************************************************************/

/*
**  The defines and includes.
*/

#define LIBRARY

#include "module.h"
#include "common.h"
#include "ptscotch.h"

/**************************************/
/*                                    */
/* These routines are the Fortran API */
/* for the mapping routines.          */
/*                                    */
/**************************************/

/*
**
*/

FORTRAN (                                       \
SCOTCHFDGRAPHMAPVIEW, scotchfdgraphmapview, (   \
SCOTCH_Dgraph * const         grafptr,          \
const SCOTCH_Dmapping * const mapptr,           \
int * const                   fileptr,          \
int * const                   revaptr),         \
(grafptr, mapptr, fileptr, revaptr))
{
  FILE *              stream;                     /* Stream to build from handle */
  int                 filenum;                    /* Duplicated handle           */
  int                 o;

  if (*fileptr == -1)                             /* If process does not want to open a stream */
    stream = NULL;
  else {
    if ((filenum = dup (*fileptr)) < 0) {         /* If cannot duplicate file descriptor */
      errorPrint ("SCOTCHFDGRAPHMAPVIEW: cannot duplicate handle");
      *revaptr = 1;                               /* Indicate error */
      return;
    }
    if ((stream = fdopen (filenum, "w")) == NULL) { /* Build stream from handle */
      errorPrint ("SCOTCHFDGRAPHMAPVIEW: cannot open output stream");
      close      (filenum);
      *revaptr = 1;
      return;
    }
  }

  o = SCOTCH_dgraphMapView (grafptr, mapptr, stream);

  if (stream != NULL)                             /* If process has an open stream */
    fclose (stream);                              /* This closes filenum too       */

  *revaptr = o;
}
